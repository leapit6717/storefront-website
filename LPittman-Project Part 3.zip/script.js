// Created by Leah Semaj Pittman
// Blush and Luxe Boutique JavaScript

// Information for all 10 products
const products = [
    {
        name: "Blush Designer Handbag",
        price: 79.99,
        category: "Handbags",
        image: "images/pink-purse.png",
        description: "A blush-pink handbag with polished gold-colored hardware."
    },
    {
        name: "Gold Charm Bracelet",
        price: 29.99,
        category: "Jewelry",
        image: "images/gold-bracelet.png",
        description: "An elegant bracelet with gold heart and star charms."
    },
    {
        name: "Rose Gold Sunglasses",
        price: 24.99,
        category: "Sunglasses",
        image: "images/rose-sunglasses.png",
        description: "Rose-gold sunglasses with softly tinted pink lenses."
    },
    {
        name: "Burgundy Luxe Wallet",
        price: 39.99,
        category: "Wallets",
        image: "images/burgundy-wallet.png",
        description: "A quilted burgundy wallet with a polished gold clasp."
    },
    {
        name: "Pink Beauty Bag",
        price: 19.99,
        category: "Beauty Accessories",
        image: "images/pink-beauty-bag.png",
        description: "A soft pink cosmetic bag with a gold-colored zipper."
    },
    {
        name: "Pearl Drop Earrings",
        price: 32.99,
        category: "Jewelry",
        image: "images/pearl-earrings.png",
        description: "Elegant pearl drop earrings with gold and crystal accents."
    },
    {
        name: "Blush High Heels",
        price: 64.99,
        category: "Shoes",
        image: "images/pink-high-heels.png",
        description: "Polished blush-pink heels with slim gold-colored accents."
    },
    {
        name: "Blush Luxe Perfume",
        price: 44.99,
        category: "Fragrance",
        image: "images/blush-perfume.png",
        description: "A feminine fragrance in an elegant blush glass bottle."
    },
    {
        name: "Blush Satin Scarf",
        price: 28.99,
        category: "Fashion Accessories",
        image: "images/satin-scarf.png",
        description: "A satin scarf with blush, burgundy, cream, and gold details."
    },
    {
        name: "Jeweled Hair Clip",
        price: 21.99,
        category: "Hair Accessories",
        image: "images/jeweled-hair-clip.png",
        description: "A gold hair clip decorated with pearls and pink crystals."
    }
];

// Display the 10 products using a JavaScript loop
const productGrid = document.getElementById("productGrid");

if (productGrid) {
    products.forEach(function(product) {
        const productCard = document.createElement("article");

        productCard.className = "product-card";

        productCard.innerHTML = `
            <img
                src="${product.image}"
                alt="${product.name}"
            >

            <h2>${product.name}</h2>

            <p>${product.description}</p>

            <p class="category">
                Category: ${product.category}
            </p>

            <p class="price">
                $${product.price.toFixed(2)}
            </p>

            <a class="button" href="cart.html">
                Add to Cart
            </a>
        `;

        productGrid.appendChild(productCard);
    });
}

// Contact form validation
const contactForm = document.getElementById("contactForm");

if (contactForm) {
    contactForm.addEventListener("submit", function(event) {
        event.preventDefault();

        const email = document
            .getElementById("contactEmail")
            .value
            .trim();

        const message = document
            .getElementById("contactMessage")
            .value
            .trim();

        const contactStatus =
            document.getElementById("contactStatus");

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (email === "" || message === "") {
            showStatus(
                contactStatus,
                "Please complete the required email and message fields.",
                false
            );

            return;
        }

        if (!emailPattern.test(email)) {
            showStatus(
                contactStatus,
                "Please enter a valid email address.",
                false
            );

            return;
        }

        showStatus(
            contactStatus,
            "Your message was submitted successfully.",
            true
        );

        contactForm.reset();
    });
}

// Checkout and coupon information
const checkoutForm = document.getElementById("checkoutForm");
const couponButton = document.getElementById("applyCoupon");

const subtotal = 84.99;
let total = subtotal;

// Apply the coupon discount
if (couponButton) {
    couponButton.addEventListener("click", function() {
        const couponCode = document
            .getElementById("couponCode")
            .value
            .trim()
            .toUpperCase();

        const couponStatus =
            document.getElementById("couponStatus");

        const discountAmount =
            document.getElementById("discountAmount");

        const orderTotal =
            document.getElementById("orderTotal");

        if (couponCode === "BLUSH20") {
            const discount = subtotal * 0.20;

            total = subtotal - discount;

            discountAmount.textContent =
                "-$" + discount.toFixed(2);

            orderTotal.textContent =
                "$" + total.toFixed(2);

            showStatus(
                couponStatus,
                "Coupon accepted. A 20% discount was applied.",
                true
            );
        } else {
            total = subtotal;

            discountAmount.textContent = "$0.00";

            orderTotal.textContent =
                "$" + subtotal.toFixed(2);

            showStatus(
                couponStatus,
                "That coupon code does not exist.",
                false
            );
        }
    });
}

// Checkout form validation
if (checkoutForm) {
    checkoutForm.addEventListener("submit", function(event) {
        event.preventDefault();

        const checkoutStatus =
            document.getElementById("checkoutStatus");

        const state =
            document.getElementById("state").value.trim();

        const zipCode =
            document.getElementById("zipCode").value.trim();

        const phoneNumber = document
            .getElementById("phoneNumber")
            .value
            .replace(/\D/g, "");

        const cardNumber = document
            .getElementById("cardNumber")
            .value
            .replace(/\s/g, "");

        const expirationDate =
            document.getElementById("expirationDate")
                .value
                .trim();

        const securityCode =
            document.getElementById("securityCode")
                .value
                .trim();

        const statePattern = /^[A-Za-z]{2}$/;
        const zipPattern = /^\d{5}$/;
        const phonePattern = /^\d{10}$/;
        const cardPattern = /^\d{16}$/;
        const expirationPattern =
            /^(0[1-9]|1[0-2])\/\d{2}$/;
        const securityPattern = /^\d{3}$/;

        if (!checkoutForm.checkValidity()) {
            checkoutForm.reportValidity();

            showStatus(
                checkoutStatus,
                "Please complete every required field.",
                false
            );

            return;
        }

        if (!statePattern.test(state)) {
            showStatus(
                checkoutStatus,
                "Enter a two-letter state abbreviation such as NC.",
                false
            );

            return;
        }

        if (!zipPattern.test(zipCode)) {
            showStatus(
                checkoutStatus,
                "The ZIP Code must contain five numbers.",
                false
            );

            return;
        }

        if (!phonePattern.test(phoneNumber)) {
            showStatus(
                checkoutStatus,
                "The phone number must contain ten numbers.",
                false
            );

            return;
        }

        if (!cardPattern.test(cardNumber)) {
            showStatus(
                checkoutStatus,
                "The demonstration card number must contain sixteen numbers.",
                false
            );

            return;
        }

        if (!expirationPattern.test(expirationDate)) {
            showStatus(
                checkoutStatus,
                "Enter the expiration date in MM/YY format.",
                false
            );

            return;
        }

        if (!securityPattern.test(securityCode)) {
            showStatus(
                checkoutStatus,
                "The security code must contain three numbers.",
                false
            );

            return;
        }

        showStatus(
            checkoutStatus,
            "All required fields are complete. Your total is $" +
                total.toFixed(2) +
                ".",
            true
        );

        setTimeout(function() {
            window.location.href =
                "order-confirmation.html";
        }, 900);
    });
}

// Display success and error messages
function showStatus(element, message, isSuccess) {
    element.textContent = message;

    if (isSuccess) {
        element.className =
            "form-status success-message";
    } else {
        element.className =
            "form-status error-message";
    }
}