// Created by Leah Semaj Pittman on September 24, 2026
// Manages products, inventory, shopping cart, forms, coupon, and checkout.

const products = [
    {
        id: 1,
        name: "Blush Designer Handbag",
        price: 79.99,
        category: "Handbags",
        stock: 5,
        image: "images/pink-purse.png",
        description: "A blush-pink handbag with polished gold-colored hardware."
    },
    {
        id: 2,
        name: "Gold Charm Bracelet",
        price: 29.99,
        category: "Jewelry",
        stock: 8,
        image: "images/gold-bracelet.png",
        description: "An elegant bracelet with gold heart and star charms."
    },
    {
        id: 3,
        name: "Rose Gold Sunglasses",
        price: 24.99,
        category: "Sunglasses",
        stock: 7,
        image: "images/rose-sunglasses.png",
        description: "Rose-gold cat-eye sunglasses with softly tinted pink lenses."
    },
    {
        id: 4,
        name: "Burgundy Luxe Wallet",
        price: 39.99,
        category: "Wallets",
        stock: 6,
        image: "images/burgundy-wallet.png",
        description: "A quilted burgundy wallet with a polished gold clasp."
    },
    {
        id: 5,
        name: "Pink Beauty Bag",
        price: 19.99,
        category: "Beauty Accessories",
        stock: 9,
        image: "images/pink-beauty-bag.png",
        description: "A soft pink cosmetic bag with a gold-colored zipper."
    },
    {
        id: 6,
        name: "Pearl Drop Earrings",
        price: 32.99,
        category: "Jewelry",
        stock: 8,
        image: "images/pearl-earrings.png",
        description: "Elegant pearl drop earrings with gold settings and crystal accents."
    },
    {
        id: 7,
        name: "Blush High Heels",
        price: 64.99,
        category: "Shoes",
        stock: 4,
        image: "images/pink-high-heels.png",
        description: "Polished blush-pink heels with slim gold-colored accents."
    },
    {
        id: 8,
        name: "Blush Luxe Perfume",
        price: 44.99,
        category: "Fragrance",
        stock: 6,
        image: "images/blush-perfume.png",
        description: "A feminine fragrance presented in an elegant blush glass bottle."
    },
    {
        id: 9,
        name: "Blush Satin Scarf",
        price: 28.99,
        category: "Fashion Accessories",
        stock: 7,
        image: "images/satin-scarf.png",
        description: "A soft satin scarf with blush, burgundy, cream, and gold details."
    },
    {
        id: 10,
        name: "Jeweled Hair Clip",
        price: 21.99,
        category: "Hair Accessories",
        stock: 10,
        image: "images/jeweled-hair-clip.png",
        description: "A gold hair clip decorated with pearls and blush-pink crystals."
    }
];

const CART_KEY = "blushLuxeCart";
const INVENTORY_KEY = "blushLuxeInventory";
const ORDER_KEY = "blushLuxeLastOrder";

function getCart() {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
}

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    updateCartCount();
}

function getInventory() {
    const savedInventory =
        JSON.parse(localStorage.getItem(INVENTORY_KEY));

    if (savedInventory) {
        return savedInventory;
    }

    const startingInventory = {};

    products.forEach(function (product) {
        startingInventory[product.id] = product.stock;
    });

    saveInventory(startingInventory);
    return startingInventory;
}

function saveInventory(inventory) {
    localStorage.setItem(
        INVENTORY_KEY,
        JSON.stringify(inventory)
    );
}

function findProduct(productId) {
    return products.find(function (product) {
        return product.id === productId;
    });
}

function calculateSubtotal(cart) {
    return cart.reduce(function (sum, item) {
        const product = findProduct(item.id);

        if (product) {
            return sum + product.price * item.quantity;
        }

        return sum;
    }, 0);
}

function updateCartCount() {
    const count = getCart().reduce(function (sum, item) {
        return sum + item.quantity;
    }, 0);

    document
        .querySelectorAll(".cart-count")
        .forEach(function (element) {
            element.textContent = count;
        });
}

function showStatus(element, message, isSuccess) {
    if (!element) {
        return;
    }

    element.textContent = message;

    if (isSuccess) {
        element.className =
            "form-status success-message";
    } else {
        element.className =
            "form-status error-message";
    }
}

/* Display the ten products on the shop page. */

const productGrid =
    document.getElementById("productGrid");

const shopStatus =
    document.getElementById("shopStatus");

function displayProducts() {
    if (!productGrid) {
        return;
    }

    const inventory = getInventory();
    productGrid.innerHTML = "";

    products.forEach(function (product) {
        const available = inventory[product.id];
        const isOutOfStock = available === 0;

        const productCard =
            document.createElement("article");

        productCard.className = "product-card";

        productCard.innerHTML = `
            <img src="${product.image}"
                 alt="${product.name}">

            <h2>${product.name}</h2>

            <p>${product.description}</p>

            <p class="category">
                Category: ${product.category}
            </p>

            <p class="price">
                $${product.price.toFixed(2)}
            </p>

            <p class="stock ${
                isOutOfStock ? "out-of-stock" : ""
            }">
                ${
                    isOutOfStock
                        ? "Out of Stock"
                        : available + " available"
                }
            </p>

            <button
                class="button add-to-cart"
                type="button"
                data-id="${product.id}"
                ${
                    isOutOfStock
                        ? 'disabled title="Out of Stock"'
                        : 'title="Add this item to your cart"'
                }>
                ${
                    isOutOfStock
                        ? "Out of Stock"
                        : "Add to Cart"
                }
            </button>
        `;

        productGrid.appendChild(productCard);
    });

    document
        .querySelectorAll(".add-to-cart")
        .forEach(function (button) {
            button.addEventListener(
                "click",
                function () {
                    addToCart(
                        Number(button.dataset.id)
                    );
                }
            );
        });
}

function addToCart(productId) {
    const product = findProduct(productId);
    const cart = getCart();
    const inventory = getInventory();

    if (!product || inventory[productId] <= 0) {
        showStatus(
            shopStatus,
            "This item is out of stock.",
            false
        );

        displayProducts();
        return;
    }

    const existingItem = cart.find(
        function (item) {
            return item.id === productId;
        }
    );

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: productId,
            quantity: 1
        });
    }

    inventory[productId] -= 1;

    saveCart(cart);
    saveInventory(inventory);

    showStatus(
        shopStatus,
        product.name + " was added to your cart.",
        true
    );

    displayProducts();
}

displayProducts();

/* Display and manage the shopping cart. */

const cartItems =
    document.getElementById("cartItems");

function displayCart() {
    if (!cartItems) {
        return;
    }

    const cart = getCart();
    const inventory = getInventory();

    const cartTotal =
        document.getElementById("cartTotal");

    const emptyCartMessage =
        document.getElementById("emptyCartMessage");

    const cartActions =
        document.getElementById("cartActions");

    cartItems.innerHTML = "";

    if (cart.length === 0) {
        emptyCartMessage.hidden = false;
        cartActions.hidden = true;
        cartTotal.textContent = "$0.00";
        return;
    }

    emptyCartMessage.hidden = true;
    cartActions.hidden = false;

    cart.forEach(function (item) {
        const product = findProduct(item.id);

        if (!product) {
            return;
        }

        const row =
            document.createElement("tr");

        row.innerHTML = `
            <td data-label="Item">
                ${product.name}
            </td>

            <td data-label="Price">
                $${product.price.toFixed(2)}
            </td>

            <td data-label="Quantity">
                <div class="quantity-controls">

                    <button
                        type="button"
                        class="quantity-button decrease"
                        data-id="${product.id}"
                        aria-label="Decrease ${product.name} quantity">
                        −
                    </button>

                    <span>${item.quantity}</span>

                    <button
                        type="button"
                        class="quantity-button increase"
                        data-id="${product.id}"
                        aria-label="Increase ${product.name} quantity"
                        ${
                            inventory[product.id] === 0
                                ? 'disabled title="Out of Stock"'
                                : ""
                        }>
                        +
                    </button>

                </div>
            </td>

            <td data-label="Item total">
                $${(
                    product.price * item.quantity
                ).toFixed(2)}
            </td>

            <td data-label="Remove">
                <button
                    type="button"
                    class="remove-button"
                    data-id="${product.id}">
                    Remove
                </button>
            </td>
        `;

        cartItems.appendChild(row);
    });

    cartTotal.textContent =
        "$" + calculateSubtotal(cart).toFixed(2);

    document
        .querySelectorAll(".decrease")
        .forEach(function (button) {
            button.addEventListener(
                "click",
                function () {
                    changeQuantity(
                        Number(button.dataset.id),
                        -1
                    );
                }
            );
        });

    document
        .querySelectorAll(".increase")
        .forEach(function (button) {
            button.addEventListener(
                "click",
                function () {
                    changeQuantity(
                        Number(button.dataset.id),
                        1
                    );
                }
            );
        });

    document
        .querySelectorAll(".remove-button")
        .forEach(function (button) {
            button.addEventListener(
                "click",
                function () {
                    removeFromCart(
                        Number(button.dataset.id)
                    );
                }
            );
        });
}

function changeQuantity(productId, amount) {
    const cart = getCart();
    const inventory = getInventory();

    const item = cart.find(
        function (cartItem) {
            return cartItem.id === productId;
        }
    );

    if (!item) {
        return;
    }

    if (amount > 0) {
        if (inventory[productId] === 0) {
            return;
        }

        item.quantity += 1;
        inventory[productId] -= 1;
    } else if (item.quantity > 1) {
        item.quantity -= 1;
        inventory[productId] += 1;
    } else {
        removeFromCart(productId);
        return;
    }

    saveCart(cart);
    saveInventory(inventory);
    displayCart();
}

function removeFromCart(productId) {
    const cart = getCart();
    const inventory = getInventory();

    const item = cart.find(
        function (cartItem) {
            return cartItem.id === productId;
        }
    );

    if (item) {
        inventory[productId] += item.quantity;
    }

    const updatedCart = cart.filter(
        function (cartItem) {
            return cartItem.id !== productId;
        }
    );

    saveCart(updatedCart);
    saveInventory(inventory);
    displayCart();
}

const clearCartButton =
    document.getElementById("clearCart");

if (clearCartButton) {
    clearCartButton.addEventListener(
        "click",
        function () {
            const cart = getCart();
            const inventory = getInventory();

            cart.forEach(function (item) {
                inventory[item.id] +=
                    item.quantity;
            });

            saveCart([]);
            saveInventory(inventory);
            displayCart();
        }
    );
}

displayCart();

/* Validate the contact form. */

const contactForm =
    document.getElementById("contactForm");

if (contactForm) {
    contactForm.addEventListener(
        "submit",
        function (event) {
            event.preventDefault();

            const email =
                document
                    .getElementById("contactEmail")
                    .value.trim();

            const message =
                document
                    .getElementById("contactMessage")
                    .value.trim();

            const contactStatus =
                document.getElementById(
                    "contactStatus"
                );

            const emailPattern =
                /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (email === "" || message === "") {
                showStatus(
                    contactStatus,
                    "Please complete the required email and message fields.",
                    false
                );
                return;
            }

            if (!emailPattern.test(email)) {
                showStatus(
                    contactStatus,
                    "Please enter a valid email address.",
                    false
                );
                return;
            }

            showStatus(
                contactStatus,
                "Your message was submitted successfully.",
                true
            );

            contactForm.reset();
        }
    );
}

/* Display the order and coupon on checkout. */

const checkoutForm =
    document.getElementById("checkoutForm");

const couponButton =
    document.getElementById("applyCoupon");

let couponApplied = false;

function displayCheckoutSummary() {
    const checkoutItems =
        document.getElementById("checkoutItems");

    if (!checkoutItems) {
        return;
    }

    const cart = getCart();

    const checkoutEmpty =
        document.getElementById("checkoutEmpty");

    const placeOrderButton =
        document.getElementById(
            "placeOrderButton"
        );

    const subtotal =
        calculateSubtotal(cart);

    const discount =
        couponApplied ? subtotal * 0.20 : 0;

    checkoutItems.innerHTML = "";

    cart.forEach(function (item) {
        const product = findProduct(item.id);

        if (product) {
            const orderLine =
                document.createElement("p");

            orderLine.innerHTML = `
                <span>
                    ${product.name} ×
                    ${item.quantity}
                </span>

                <strong>
                    $${(
                        product.price *
                        item.quantity
                    ).toFixed(2)}
                </strong>
            `;

            checkoutItems.appendChild(
                orderLine
            );
        }
    });

    checkoutEmpty.hidden =
        cart.length !== 0;

    placeOrderButton.disabled =
        cart.length === 0;

    document.getElementById(
        "subtotalAmount"
    ).textContent =
        "$" + subtotal.toFixed(2);

    document.getElementById(
        "discountAmount"
    ).textContent =
        discount === 0
            ? "$0.00"
            : "-$" + discount.toFixed(2);

    document.getElementById(
        "orderTotal"
    ).textContent =
        "$" + (subtotal - discount).toFixed(2);
}

if (couponButton) {
    couponButton.addEventListener(
        "click",
        function () {
            const couponCode =
                document
                    .getElementById("couponCode")
                    .value.trim()
                    .toUpperCase();

            const couponStatus =
                document.getElementById(
                    "couponStatus"
                );

            if (couponCode === "BLUSH20") {
                couponApplied = true;

                showStatus(
                    couponStatus,
                    "Coupon accepted. A 20% discount was applied.",
                    true
                );
            } else {
                couponApplied = false;

                showStatus(
                    couponStatus,
                    "That coupon code does not exist.",
                    false
                );
            }

            displayCheckoutSummary();
        }
    );
}

displayCheckoutSummary();

/* Validate checkout and complete the order. */

if (checkoutForm) {
    checkoutForm.addEventListener(
        "submit",
        function (event) {
            event.preventDefault();

            const checkoutStatus =
                document.getElementById(
                    "checkoutStatus"
                );

            const cart = getCart();

            const zipCode =
                document
                    .getElementById("zipCode")
                    .value.trim();

            const phoneNumber =
                document
                    .getElementById("phoneNumber")
                    .value.replace(/\D/g, "");

            const state =
                document
                    .getElementById("state")
                    .value.trim();

            const cardNumber =
                document
                    .getElementById("cardNumber")
                    .value.replace(/\s/g, "");

            const expirationDate =
                document
                    .getElementById(
                        "expirationDate"
                    )
                    .value.trim();

            const securityCode =
                document
                    .getElementById(
                        "securityCode"
                    )
                    .value.trim();

            if (cart.length === 0) {
                showStatus(
                    checkoutStatus,
                    "Your cart is empty. Add an item before checking out.",
                    false
                );
                return;
            }

            if (!checkoutForm.checkValidity()) {
                checkoutForm.reportValidity();

                showStatus(
                    checkoutStatus,
                    "Please complete every required field.",
                    false
                );
                return;
            }

            if (!/^[A-Za-z]{2}$/.test(state)) {
                showStatus(
                    checkoutStatus,
                    "Enter the two-letter state abbreviation, such as NC.",
                    false
                );
                return;
            }

            if (!/^\d{5}$/.test(zipCode)) {
                showStatus(
                    checkoutStatus,
                    "The ZIP Code must contain five numbers.",
                    false
                );
                return;
            }

            if (!/^\d{10}$/.test(phoneNumber)) {
                showStatus(
                    checkoutStatus,
                    "The phone number must contain ten numbers.",
                    false
                );
                return;
            }

            if (!/^\d{16}$/.test(cardNumber)) {
                showStatus(
                    checkoutStatus,
                    "The demonstration card number must contain sixteen numbers.",
                    false
                );
                return;
            }

            if (
                !/^(0[1-9]|1[0-2])\/\d{2}$/.test(
                    expirationDate
                )
            ) {
                showStatus(
                    checkoutStatus,
                    "Enter the expiration date in MM/YY format.",
                    false
                );
                return;
            }

            if (!/^\d{3}$/.test(securityCode)) {
                showStatus(
                    checkoutStatus,
                    "The security code must contain three numbers.",
                    false
                );
                return;
            }

            const subtotal =
                calculateSubtotal(cart);

            const discount =
                couponApplied
                    ? subtotal * 0.20
                    : 0;

            const order = {
                customerName:
                    document
                        .getElementById(
                            "shippingName"
                        )
                        .value.trim(),

                items: cart,
                subtotal: subtotal,
                discount: discount,
                total: subtotal - discount,

                orderNumber:
                    "BL" +
                    Date.now()
                        .toString()
                        .slice(-6)
            };

            localStorage.setItem(
                ORDER_KEY,
                JSON.stringify(order)
            );

            saveCart([]);

            window.location.href =
                "order-confirmation.html";
        }
    );
}

/* Display the completed order. */

const confirmationDetails =
    document.getElementById(
        "confirmationDetails"
    );

if (confirmationDetails) {
    const order =
        JSON.parse(
            localStorage.getItem(ORDER_KEY)
        );

    if (!order) {
        confirmationDetails.innerHTML =
            "<p>No recent order was found.</p>";
    } else {
        document.getElementById(
            "confirmationName"
        ).textContent =
            order.customerName;

        document.getElementById(
            "orderNumber"
        ).textContent =
            order.orderNumber;

        document.getElementById(
            "confirmationItems"
        ).innerHTML =
            order.items
                .map(function (item) {
                    const product =
                        findProduct(item.id);

                    if (!product) {
                        return "";
                    }

                    return `
                        <li>
                            ${product.name} ×
                            ${item.quantity} —
                            $${(
                                product.price *
                                item.quantity
                            ).toFixed(2)}
                        </li>
                    `;
                })
                .join("");

        document.getElementById(
            "confirmationTotal"
        ).textContent =
            "$" + order.total.toFixed(2);
    }
}

updateCartCount();